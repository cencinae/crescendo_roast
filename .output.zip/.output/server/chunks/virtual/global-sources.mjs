const sources = [
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/admin/config"
            },
            {
                "loc": "/admin/hero"
            },
            {
                "loc": "/admin/login"
            },
            {
                "loc": "/admin/orders"
            },
            {
                "loc": "/admin/products"
            },
            {
                "loc": "/admin/products-new"
            },
            {
                "loc": "/admin"
            },
            {
                "loc": "/cafes"
            },
            {
                "loc": "/"
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
