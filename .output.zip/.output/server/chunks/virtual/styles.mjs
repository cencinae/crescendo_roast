const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('../build/index-styles.KbVznZtx.mjs').then(interopDefault),
  "pages/cafes/index.vue": () => import('../build/index-styles-2.uTYaMSPu.mjs').then(interopDefault),
  "pages/cafes/[slug].vue": () => import('../build/_slug_-styles.GOTxjOry.mjs').then(interopDefault),
  "components/sections/CategoriesSection.vue": () => import('../build/CategoriesSection-styles.CfPhkd85.mjs').then(interopDefault),
  "components/sections/WholesaleBanner.vue": () => import('../build/WholesaleBanner-styles.CxIWv-up.mjs').then(interopDefault),
  "components/sections/ScheduleSection.vue": () => import('../build/ScheduleSection-styles.CIO1dolH.mjs').then(interopDefault),
  "node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.DdskOJaF.mjs').then(interopDefault),
  "node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.goc7A4aP.mjs').then(interopDefault),
  "layouts/default.vue": () => import('../build/default-styles.BgEnrTd2.mjs').then(interopDefault),
  "components/modals/ProductDetailModal.vue": () => import('../build/ProductDetailModal-styles.iz9sQ-ga.mjs').then(interopDefault),
  "components/modals/CartDrawer.vue": () => import('../build/CartDrawer-styles.hgh9mR8h.mjs').then(interopDefault),
  "components/modals/CheckoutModal.vue": () => import('../build/CheckoutModal-styles.DACzaF0X.mjs').then(interopDefault),
  "components/modals/ThankYouModal.vue": () => import('../build/ThankYouModal-styles.BZhFedZL.mjs').then(interopDefault),
  "components/ui/Toast.vue": () => import('../build/Toast-styles.DxwOCXh8.mjs').then(interopDefault)
};

const inlinedCSS = {"default.DNo3IPsL.css":[["layouts/default.vue","components/modals/ProductDetailModal.vue"],["layouts/default.vue","components/modals/CartDrawer.vue"],["layouts/default.vue","components/modals/CheckoutModal.vue"],["layouts/default.vue","components/modals/ThankYouModal.vue"],["layouts/default.vue","components/ui/Toast.vue"]],"error-404.D_zGJsVb.css":[["node_modules/nuxt/dist/app/components/error-404.vue"]],"error-500.Bw4Q3Qtx.css":[["node_modules/nuxt/dist/app/components/error-500.vue"]],"_slug_.CDtT80w1.css":[["pages/cafes/[slug].vue"]],"cafes.BISEQAyv.css":[["pages/cafes/index.vue"]],"pages.U4uNxuHc.css":[["pages/index.vue","components/sections/CategoriesSection.vue"],["pages/index.vue","components/sections/WholesaleBanner.vue"],["pages/index.vue","components/sections/ScheduleSection.vue"]]};

export { styles as default, inlinedCSS };
//# sourceMappingURL=styles.mjs.map
