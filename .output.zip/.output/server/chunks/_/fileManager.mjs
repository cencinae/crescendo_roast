import fs from 'fs';
import path from 'path';

const readJsonFile = (filePath) => {
  try {
    if (!fs.existsSync(filePath)) return [];
    const content = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(content);
  } catch (error) {
    console.error("Error leyendo archivo:", error);
    return [];
  }
};
const writeJsonFile = (filePath, data) => {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
};
const getPublicPath = (relativePath) => {
  return path.join(process.cwd(), "public", relativePath);
};
const deleteImageFile = (imageUrl) => {
  try {
    if (!imageUrl || !imageUrl.startsWith("/uploads/")) {
      return { success: false, reason: "No es un archivo local" };
    }
    const fileName = imageUrl.replace("/uploads/", "");
    if (fileName.includes("..") || fileName.includes("/")) {
      return { success: false, reason: "Ruta inv\xE1lida" };
    }
    const filePath = path.join(process.cwd(), "public", "uploads", fileName);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return { success: true, deleted: filePath };
    }
    return { success: false, reason: "Archivo no existe" };
  } catch (error) {
    console.error("Error eliminando imagen:", error);
    return { success: false, reason: error.message };
  }
};

export { deleteImageFile as d, getPublicPath as g, readJsonFile as r, writeJsonFile as w };
//# sourceMappingURL=fileManager.mjs.map
