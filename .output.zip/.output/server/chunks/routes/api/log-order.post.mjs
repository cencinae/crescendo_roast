import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';

const logOrder_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const dataDir = path.join(process.cwd(), "server", "data");
    const ordersFile = path.join(dataDir, "orders.json");
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    let orders = [];
    if (fs.existsSync(ordersFile)) {
      const content = fs.readFileSync(ordersFile, "utf-8");
      try {
        orders = JSON.parse(content);
        if (!Array.isArray(orders)) orders = [];
      } catch (e) {
        orders = [];
      }
    }
    orders.unshift(body);
    fs.writeFileSync(ordersFile, JSON.stringify(orders, null, 2), "utf-8");
    return {
      success: true,
      message: "Pedido registrado",
      orderNumber: body.orderNumber
    };
  } catch (error) {
    console.error("Error en log-order:", error);
    throw createError({
      statusCode: 500,
      message: "Error al registrar el pedido"
    });
  }
});

export { logOrder_post as default };
//# sourceMappingURL=log-order.post.mjs.map
