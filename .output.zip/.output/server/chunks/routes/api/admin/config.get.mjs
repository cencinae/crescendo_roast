import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const config_get = defineEventHandler(async () => {
  const filePath = getPublicPath("api/config.json");
  const config = readJsonFile(filePath);
  if (!config || Object.keys(config).length === 0) {
    return {
      whatsapp: { number: "56931893121", defaultMessage: "Hola!", b2bMessage: "Hola!" },
      shipping: { cost: 2500, freeThreshold: 15e3, city: "Talca", region: "Regi\xF3n del Maule" },
      bankAccount: { bank: "Banco Estado", accountType: "Cuenta Vista", accountNumber: "", rut: "", holder: "" },
      paymentMethods: [
        { id: "efectivo", label: "Efectivo", icon: "fa-solid fa-money-bill-wave", available: true },
        { id: "tarjeta", label: "Tarjeta", icon: "fa-solid fa-credit-card", available: true },
        { id: "transferencia", label: "Transferencia", icon: "fa-solid fa-building-columns", available: true },
        { id: "link", label: "Link de Pago", icon: "fa-solid fa-link", available: false }
      ],
      socials: [
        { name: "Instagram", icon: "fa-brands fa-instagram", url: "" },
        { name: "Facebook", icon: "fa-brands fa-facebook-f", url: "" },
        { name: "TikTok", icon: "fa-brands fa-tiktok", url: "" },
        { name: "WhatsApp", icon: "fa-brands fa-whatsapp", url: "" }
      ]
    };
  }
  return config;
});

export { config_get as default };
//# sourceMappingURL=config.get.mjs.map
