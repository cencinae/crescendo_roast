import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile, d as deleteImageFile, w as writeJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const products_delete = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const filePath = getPublicPath("api/products.json");
  const products = readJsonFile(filePath);
  const productToDelete = products.find((p) => p.id === body.id);
  if (productToDelete && productToDelete.image) {
    const deleteResult = deleteImageFile(productToDelete.image);
    if (deleteResult.success) {
      console.log(`\u2713 Imagen eliminada: ${deleteResult.deleted}`);
    }
  }
  const filtered = products.filter((p) => p.id !== body.id);
  writeJsonFile(filePath, filtered);
  return { success: true };
});

export { products_delete as default };
//# sourceMappingURL=products.delete.mjs.map
