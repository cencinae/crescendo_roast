import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const products_get = defineEventHandler(async () => {
  const filePath = getPublicPath("api/products.json");
  const products = readJsonFile(filePath);
  return products;
});

export { products_get as default };
//# sourceMappingURL=products.get.mjs.map
