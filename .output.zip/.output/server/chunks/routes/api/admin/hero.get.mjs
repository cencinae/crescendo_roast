import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const hero_get = defineEventHandler(async () => {
  const filePath = getPublicPath("api/hero.json");
  const hero = readJsonFile(filePath);
  if (!hero || Object.keys(hero).length === 0) {
    return {
      description: "",
      image: "/cafe.jpg",
      badge: { label: "", country: "", producer: "" },
      score: { value: 0, suffix: "SCA" }
    };
  }
  return hero;
});

export { hero_get as default };
//# sourceMappingURL=hero.get.mjs.map
