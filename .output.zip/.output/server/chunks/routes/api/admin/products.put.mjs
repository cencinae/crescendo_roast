import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile, d as deleteImageFile, w as writeJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const products_put = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const filePath = getPublicPath("api/products.json");
  const products = readJsonFile(filePath);
  const index = products.findIndex((p) => p.id === body.id);
  if (index === -1) {
    throw createError({ statusCode: 404, message: "Producto no encontrado" });
  }
  const oldProduct = products[index];
  const oldImage = oldProduct.image;
  const newImage = body.image;
  if (oldImage && newImage && oldImage !== newImage) {
    const deleteResult = deleteImageFile(oldImage);
    if (deleteResult.success) {
      console.log(`\u2713 Imagen anterior eliminada: ${deleteResult.deleted}`);
    }
  }
  products[index] = { ...oldProduct, ...body };
  writeJsonFile(filePath, products);
  return { success: true, product: products[index] };
});

export { products_put as default };
//# sourceMappingURL=products.put.mjs.map
