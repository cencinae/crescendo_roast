import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile, d as deleteImageFile, w as writeJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const hero_put = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const filePath = getPublicPath("api/hero.json");
  const oldHero = readJsonFile(filePath);
  const oldImage = oldHero == null ? void 0 : oldHero.image;
  const newImage = body.image;
  if (oldImage && newImage && oldImage !== newImage) {
    const deleteResult = deleteImageFile(oldImage);
    if (deleteResult.success) {
      console.log(`\u2713 Imagen hero anterior eliminada: ${deleteResult.deleted}`);
    }
  }
  writeJsonFile(filePath, body);
  return { success: true, message: "Hero actualizado correctamente" };
});

export { hero_put as default };
//# sourceMappingURL=hero.put.mjs.map
