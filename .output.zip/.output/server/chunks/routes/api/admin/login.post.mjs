import { d as defineEventHandler, r as readBody, u as useRuntimeConfig } from '../../../nitro/nitro.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';

const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const config = useRuntimeConfig();
  const { username, password } = body;
  const validUser = config.adminUsername || "admin";
  const validPass = config.adminPassword || "Crescendo2026!";
  if (username === validUser && password === validPass) {
    const token = Buffer.from(`${username}:${Date.now()}`).toString("base64");
    return {
      success: true,
      token,
      user: { username }
    };
  }
  return {
    success: false,
    error: "Credenciales inv\xE1lidas"
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
