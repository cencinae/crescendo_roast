import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, w as writeJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const config_put = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const filePath = getPublicPath("api/config.json");
  if (!body.whatsapp || !body.shipping) {
    throw createError({ statusCode: 400, message: "Datos de configuraci\xF3n inv\xE1lidos" });
  }
  writeJsonFile(filePath, body);
  return { success: true, message: "Configuraci\xF3n guardada correctamente" };
});

export { config_put as default };
//# sourceMappingURL=config.put.mjs.map
