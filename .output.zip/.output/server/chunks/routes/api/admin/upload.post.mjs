import { d as defineEventHandler, a as readMultipartFormData, c as createError } from '../../../nitro/nitro.mjs';
import { mkdir, writeFile } from 'fs/promises';
import { join } from 'path';
import { randomUUID } from 'crypto';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';

const upload_post = defineEventHandler(async (event) => {
  try {
    const items = await readMultipartFormData(event);
    if (!items || items.length === 0) {
      throw createError({ statusCode: 400, message: "No se recibi\xF3 archivo" });
    }
    const file = items[0];
    const fileName = file.filename || "image.jpg";
    const ext = fileName.split(".").pop();
    const uniqueName = `${randomUUID()}.${ext}`;
    const uploadsDir = join(process.cwd(), "public", "uploads");
    await mkdir(uploadsDir, { recursive: true });
    const filePath = join(uploadsDir, uniqueName);
    await writeFile(filePath, file.data);
    return {
      success: true,
      url: `/uploads/${uniqueName}`,
      filename: uniqueName
    };
  } catch (error) {
    console.error("Error subiendo archivo:", error);
    throw createError({
      statusCode: 500,
      message: "Error al subir la imagen"
    });
  }
});

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
