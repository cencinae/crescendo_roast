import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { g as getPublicPath, r as readJsonFile, w as writeJsonFile } from '../../../_/fileManager.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';
import 'ipx';
import 'fs';
import 'path';

const products_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const filePath = getPublicPath("api/products.json");
  const products = readJsonFile(filePath);
  const maxId = products.length > 0 ? Math.max(...products.map((p) => p.id)) : 0;
  const newProduct = {
    ...body,
    id: maxId + 1
  };
  products.push(newProduct);
  writeJsonFile(filePath, products);
  return { success: true, product: newProduct };
});

export { products_post as default };
//# sourceMappingURL=products.post.mjs.map
